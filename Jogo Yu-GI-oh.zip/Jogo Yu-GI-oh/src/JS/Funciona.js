const estado = {
    pontua:{
        playerPonto: 0,
        pcPonto: 0,
        pontoBox: document.getElementById('score-pontos')
    },
    CartaEspirito:{
        avatar: document.getElementById('carta-img'),
        nome: document.getElementById('nome-carta'),
        avatar: document.getElementById('tipo-carta')
    },
    Cartas:{
        player: document.getElementById('player-carta'),
        player: document.getElementById('pc-carta')
    },
    action:{
        Button: document.getElementById('pc-carta')
    }
}

const playerSide = {
    player1: document.getElementById('player-carta'),
    Pc: document.getElementById('pc-carta')
}

const caminhoImg = ".src/assets/icons/"
const cartaDados = [
    {
        id: 0,
        nome: "Dragão branco de olhos azuis",
        tipo: "papel",
        img: `${caminhoImg}+"dragon.png"`,
        winOf: [1],
        loseOf: [2]
    },
    {
        id: 1,
        nome: "Magico negro",
        tipo: "pedra",
        img: `${caminhoImg}+"magician.png"`,
        winOf: [2],
        loseOf: [0]
    },
    {
        id: 2,
        nome: "Exodia",
        tipo: "Tesoura",
        img: `${caminhoImg}+"exodia.png"`,
        winOf: [0],
        loseOf: [1]
    }
];

async function getAliatorioCarta(){
    const randomIndex = Math.floor(Math.random() * cartaDados.length);
    return cartaDados[randomIndex].id;
}

async function criarCartasImg(randomIdCarta, para){

    const cartaImg = document.criarCartasImg("img");
    cartaImg.setAttribute("height", "100px");
    cartaImg.setAttribute("src", ".src/assets/icons/card-back.png");
    cartaImg.setAttribute("data-id", randomIdCarta);
    cartaImg.classList.add("card");


    if(para === playerSide.player1){
        cartaImg.addEventListener("click", ()=>{
            setCartaSeta(cartaImg.getAttribute("data-id"))
        })
    }

    cartaImg.addEventListener("mouseover", () => {
        drowCartas(randomIndex)
    })


}

async function drowCartas(numero, para){
    for(let i = 0; i < numero; i++){
        const AliId = await getAliatorioCarta();
        const cartaImg = await criarCartasImg(randomIdCarta, para);

        document.getElementById(para).appendChild(cartaImg)
    }
}


function init(){
    drowCartas(5, playerSide.player1);
    drowCartas(5, playerSide.Pc);
}

init();